"""empty message

Revision ID: 3c420d1b9335
Revises: 0b64aa009f8b, 20231027100000
Create Date: 2025-06-16 17:30:58.321230

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '3c420d1b9335'
down_revision = ('0b64aa009f8b', '20231027100000')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
