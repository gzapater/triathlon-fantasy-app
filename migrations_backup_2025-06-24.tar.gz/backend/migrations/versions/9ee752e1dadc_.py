"""empty message

Revision ID: 9ee752e1dadc
Revises: 3c420d1b9335, abcdef123456
Create Date: 2025-06-24 09:52:46.894038

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '9ee752e1dadc'
down_revision = ('3c420d1b9335', 'abcdef123456')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
